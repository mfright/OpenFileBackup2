#!/bin/bash
java -jar 1_OpenFileBackup.jar
